<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class MahasiswaController extends Controller
{
    public function index(){
        $mahasiswa = DB::table('mahasiswa')->get();
        return view('mahasiswa.index',['mahasiswa' => $mahasiswa]);
    }
    public function coba(){
        return 'Hello';
    }
    public function show($id)
    {
        return view('user.profile', ['user' => User::findOrFail($id)]);
    }
}